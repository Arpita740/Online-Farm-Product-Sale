var express = require('express');
const crypto = require("crypto");
var ejs = require('ejs');
var bodyParser = require('body-parser');
var mysql = require('mysql');
var session =require('express-session');
const con = mysql.createConnection({
    host:"localhost",
    user: "root",
    password:"",
    database:"node_project"
})
var app = express();
const bcrypt = require('bcrypt');
const saltRounds = 10;

app.use(express.static('public'));
app.set('view engine','ejs');


app.use(bodyParser.urlencoded({extended: true}));
app.use(session({secret:"secret"}));
app.use(express.json())

app.listen(8100);

function isProductInCart(cart,id){
    for(let i=0;i<cart.length;i++){
        if(cart[i].id==id){
            return true;
        }
    }

    return false;
}

function calculateTotal(cart,req){
     total=0;
    for(let i=0;i<cart.length;i++){
        
       if(parseInt(cart[i].sale_price)){
            total=total+(parseInt(cart[i].sale_price)*parseInt(cart[i].quantity));

        }else{
            total=total+(parseInt(cart[i].price)*parseInt(cart[i].quantity));
        }
    }
    req.session.total=total;
    return total;
}
//localhost:8100
app.get('/',function(req,res){
    con.query("SELECT * FROM products",(err,result)=>{
        res.render('pages/index',{result:result});

    })
});



con.connect(function(error){
    if(error) throw error
    else console.log("connected to database successfully!")
});

app.post('/add_to_cart',function(req,res){

    var id=req.body.id;
    var name= req.body.name;
    var price= req.body.price;
    var sale_price= req.body.sale_price;
    var quantity= req.body.quantity;
    var image= req.body.image;
    var product={id:id,name:name,price:price,sale_price:sale_price,quantity:quantity,image:image};

    if(req.session.cart){
        var cart= req.session.cart;
        if(!isProductInCart(cart,id)){
            cart.push(product);
        }
    }else{

        req.session.cart=[product];
        var cart=req.session.cart;
    }

    //calculate total
    calculateTotal(cart,req);

    //return to cart page
    res.redirect('/cart');
});



app.get('/add_to_cart',function(req,res){

    var cart=req.session.cart;
    var total=req.session.total;

    res.render('pages/cart',{cart:cart,total:total});
});


app.get('/admin',function(req,res){

    res.render('pages/admin');
});

app.get('/login', function(req,res) {
    
    res.render('pages/login');
});

app.get('/cart', function(req, res) {
    const total= req.session.total;
    const cart = req.session.cart|| [] ;
    res.render("pages/cart",{cart:cart,total:total})
    });


app.post('/remove_product',function(req,res){
    var id= req.body.id;
    var cart= req.session.cart;

    for(let i=0;i<cart.length;i++){
        if(cart[i].id==id){
            cart.splice(cart.indexOf(i),1);
        }
    }


    //recalculate total
    calculateTotal(cart,req);
    res.redirect('/cart');
});

app.get("/signup", (req, res) => {
    res.render("pages/signup");
});

app.get("/adsign", (req, res) => {
    res.render("pages/adsign");

});

app.get("/addpro", (req, res) => {
    res.render("pages/addpro");
});

app.get("/api/getallorders", (req, res) => {
    con.query("SELECT * FROM `orders`",[],(err,result)=>{
        res.json(result)
    })
    
});
app.get("/api/getcustomerscount", (req, res)=> {
    con.query("SELECT COUNT(*) AS COUNT FROM `customer`", (err, result) => {
        res.json(result);
    })
})
app.post('/edit_product_quantity',function(req,res){
    //get value from input
     var id=req.body.id;
     var quantity=req.body.quantity;
     var increase_btn=req.body.increase_product_quantity;
     var decrease_btn = req.body.decrease_product_quantity;
     var cart= req.session.cart;
     if(increase_btn){
        for(let i=0;i<cart.length;i++){
            if(cart[i].id==id){
                if(cart[i].quantity >0){
                    cart[i].quantity=parseInt(cart[i].quantity)+1;

                }
            }
        }
     }
     if(decrease_btn){
        for(let i=0;i<cart.length;i++){
            if(cart[i].id==id){
                if(cart[i].quantity >1){
                    cart[i].quantity=parseInt(cart[i].quantity)-1;

                }
            }
        }
     }
     calculateTotal(cart,req);
     res.redirect('/cart');
});
app.get('/checkout',function(req,res){
    var total=req.session.total
    res.render('pages/checkout',{total:total})
});

app.post('/place_order',function(req,res){
    console.log(req.body)
        var name=req.body.name;
        var email=req.body.email;
        var phone=req.body.phone;
        var city=req.body.city;
        var address=req.body.address;

        var cost=req.session.total;
        var status=" paid";
        var date=new Date();
        var products_ids="";

        var cart=req.session.cart;
        for(let i=0;i<cart.length;i++){
            products_ids=products_ids +","+ cart[i].id;
        }
        
               console.log("Connected")
                var query="INSERT INTO orders(cost,name,email,status,city,address,phone,date,products_ids) VALUES ?";
                var values=[
                    [cost,name,email,status,city,address,phone,date,products_ids]
                ];
                con.query(query,[values],(err,result)=>{
                    res.redirect('/payment');
                });
                
                var query2="INSERT INTO payments(transaction_id) VALUES ?";
                var values2= [
                [crypto.randomBytes(3).toString("hex")]
            ]
            con.query(query2,[values2],(err,result)=>{
                if (err) console.log(err)
            });
         
});


app.post("/api/signup", (req, res) => {
    bcrypt.hash(req.body.password, saltRounds, function(err, hash) {
    var query="INSERT INTO customer(cusername,cpassword,cphone, cfname) VALUES ?";
                var values=[
                    [req.body.username, hash, req.body.phone,req.body.name]
                ];
                con.query(query,[values],(err,result)=>{
                    if(err) console.log(err.message);
                    res.redirect('/');
                });
            });
});

app.post("/api/adsign", (req, res) => {
    bcrypt.hash(req.body.password, saltRounds, function(err, hash) {
    var query="INSERT INTO admin(admin_id,apassword,aphone) VALUES ?";
                var values=[
                    [req.body.username, hash, req.body.phone]
                ];
                con.query(query,[values],(err,result)=>{
                    if(err) console.log(err.message);
                    res.redirect('/');
                });
            });
});



app.get('/payment',function(req,res){
    res.render("pages/payment")
});



